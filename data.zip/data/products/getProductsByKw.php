<?php
//data/products/getProductsByKw.php
header("Content-Type:application/json");
require_once("../init.php");
@$kw = $_REQUEST["kw"];
$sql="select *,(select md from xz_laptop_pic where laptop_id=lid limit 1) as md from xz_laptop";
if($kw){
	$kws=explode(" ",$kw);
	for($i=0;$i<count($kws);$i++){
	  $kws[$i]= " title like '%$kws[$i]%' ";
	}
    $where = implode(" and ",$kws);
    $sql.=" where $where ";
}
$result=mysqli_query($conn,$sql);
$data = mysqli_fetch_all($result,1);
$count=count($data);
$output = [];
@$pageNo=$_REQUEST["pageNo"];
if($pageNo==null)$pageNo=1;

@$pageSize=$_REQUEST["pageSize"];
   if($pageSize==null)$pageSize=9;

$pageCount=ceil(($count/$pageSize));
	$sql.=" limit ". ($pageNo-1)*$pageSize .",$pageSize";
	     $result=mysqli_query($conn,$sql);
    	 $data = mysqli_fetch_all($result,1);
	$output=[
			"pageSize"=>$pageSize,
			"pageNo"=>$pageNo,
			"count"=>$count,
			"pageCount"=>$pageCount,
			"data"=>$data
	];
	echo json_encode($output);