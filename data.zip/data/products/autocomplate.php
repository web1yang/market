<?php
  header("Content-Type:application/json");
  require_once("../init.php");
  @$kw = $_REQUEST["term"];
  $sql = "select lid,title,sold_count  from xz_laptop";
 if($kw){
 $kws=explode(" ",$kw);
 for($i=0;$i<count($kws);$i++){
    $kws[$i]=" title like '% ".$kws[$i]."%' ";
 }
 $where = " where ".implode(" and ",$kws);
  $sql.=$where;
 }
 $sql.="order by sold_count desc limit 10";
 $result = mysqli_query($conn,$sql);
 echo json_encode(mysqli_fetch_all($result,1));