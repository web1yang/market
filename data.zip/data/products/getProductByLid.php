<?php
//data/products/getProductByLid.php
header("Content-Type:application/json");
require("../init.php");
@$lid= $_REQUEST["lid"];
$output=[
//product=>{lid,family_id,title....}
//sepcs=>[{lid,spec},{lid,spec}]
//imgs=>{[lg,md,sm]}
];
if($lid){
$sql= "select *from xz_laptop where lid=$lid";
$result = mysqli_query($conn,$sql);
$product=mysqli_fetch_all($result,1)[0];
$output["product"]=$product;
$family_id=$product["family_id"];
$sql = "select lid,spec from xz_laptop where family_id=$family_id";
$result= mysqli_query($conn,$sql);
$spec=mysqli_fetch_all($result,1);
$output["spec"]=$spec;
$sql = "select * from xz_laptop_pic where laptop_id=$lid";
$result= mysqli_query($conn,$sql);
$imgs=mysqli_fetch_all($result,1);
 $output["imgs"]= $imgs;
}
echo json_encode($output);