<?php
header("Content-type:application/json");
require_once("../init.php");
$sql="SELECT * FROM `xz_index_carousel`";
$result= mysqli_query($conn,$sql);
echo json_encode(mysqli_fetch_all($result,1));