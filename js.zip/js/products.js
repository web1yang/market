function loadPage(pageNo=1){
      var pageSize=9;
      var search=location.search;
      var query=`pageNo=${pageNo}&pageSize=${pageSize}`;
      if(search!=""){
          search=decodeURI(search.split("=")[1]);
          query+=`&kw=${search}`;
      }
      console.log(search);
    $.ajax({type:"get",
           url:"data/products/getProductsByKw.php",
           data:query,
           dataType:"json"
    }).then(result=>{
        //console.log(html);
        var html="";
        var {pageSize,pageNo,count,pageCount,data}=result;
          console.log(data)
         for( p of data){
                html+=`<li>
                    <a href="product_details.html?lid=${p.lid}">
                    <img src="${p.md}" alt="">
                    </a>
                    <p>
                    ¥<span class="price">${p.price}</span>
                    <a href="product_details.html?lid=${p.lid}">${p.title}</a>
                    </p>
                    <div>
                    <span class="reduce">-</span>
                    <input type="text" value="1">
                    <span class="add">+</span>
                    <a href="javascript:;" data-lid="${p.lid}" class="addCart">加入购物车</a>
                    </div>
                </li>`;
          }
       document.getElementById("show-list").innerHTML=html;
     //分页
     var html="";
     html+=`<a href="javascript:;" class='${pageNo==1?"previous disabled":"previous"}'>上一页</a>`;
     for(var i=1;i<=pageCount;i++){
         html+=`<a href="javascript:;" class=${pageNo==i?"current":""}>${i}</a>`;
     }
     html+=`<a href="javascript:;" class='${pageNo==pageCount?"next disabled":"next"}'>下一页</a>`;
    document.getElementById("pages").innerHTML=html
})

}
function loadCart(){
    $.get("data/users/islogin.php").then(data=>{
        if(data.ok==1){
        $.get("data/cart/getCart.php")
            .then(term=>{
                    var html="",total=0;
                    //console.log(term);
                    for(var p of term){
                        html+=`<div class="item">
                        <span>${p.title}</span>
                        <div data-iid="${p.iid}">
                        <span class="reduce">-</span>
                        <input type="text" value="${p.count}">
                        <span class="add">+</span>
                        </div>
                        <p>
                        <span>¥${(p.price * p.count).toFixed(2)}</span>
                        </p>
                        </div>`;
                        total+=p.price * p.count;
             }
              //console.log(total);
            $(".cart_content").html(html);
            $("#total").html(total.toFixed(2));
      })
    }
    })
}
$(()=>{
    loadPage();
    loadCart()
});
(()=>{
    var divPages=document.getElementById("pages");
     divPages.onclick=e=>{
      var tar = e.target;
    if(tar.nodeName=="A"&& !/disabled|current/.test(tar.className)){
        var i=1;
        if(/previous/.test(tar.className)){
           var a=divPages.querySelector(".current")
            i= parseInt(a.innerHTML)-1;
        }else if(/next/.test(tar.className)){
            var a=divPages.querySelector(".current");
             i=parseInt(a.innerHTML)+1;
              console.log(i)
        }else{
            i=parseInt(tar.innerHTML);
        }

        loadPage(i);
    }
}
})();
(()=>{
    document.getElementById("show-list").onclick=e=>{
      var tar = e.target;
    if(tar.className=="add"||tar.className=="reduce"){
        var input= tar.parentNode.children[1];
        var n=input.value;
        if(tar.className=="add"){
             n++;
        }else if(n>1){
           n--;
        }
        input.value=n;
    }
    }
    $("#show-list").on(
        "click",
         ".addCart",
        e=>{
        var $tar= $(e.target);
        $.get("data/users/islogin.php").then(data=>{
            if(data.ok==0)
            location="login.html?back="+location.href;
            else{
             var lid= $tar.data("lid"),
                 count=$tar.prev().prev().val();
                $.post("data/cart/addCart.php",{lid,count})
                    .then(()=>{
                     //alert("添加成功");
                      loadCart();
                    $tar.prev().prev().val(1);
                })

                  }
        }
        );
    }
    );
})();
(()=>{
    $("#cart").on(
                "click",
                ".add,.reduce",
                  e=>{
                   var $tar =$(e.target);
                   var count=$tar.parent().children(":eq(1)").val();
                   var iid=$tar.parent().data("iid");
                   if($tar.is(".add")){
                    count++;
                    }else{
                    count--;
                      }
                    $.get("data/cart/updateCount.php",{iid,count}).then(
                        ()=>{ loadCart();}
                    );
                      })
              .on(
                    "click",
                    ".title>a",
                        e=>{
                        e.preventDefault();
                        $.get("data/cart/clearCart.php").then(()=>{
                            $(".cart_content").empty();
                            $("#total").html("0.00");
                        })
                    }
    )
})()