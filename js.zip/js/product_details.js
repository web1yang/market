//放大镜
(()=>{
    var [aBackward,aForward]=document.querySelectorAll("#preview>h1>a");
//console.log( aForward,aBackward);
var ul=document.querySelector("#icon_list");
var mImg=document.querySelector("#mImg");
var largeDiv = document.querySelector("#largeDiv");
var mask=document.querySelector("#mask");
var superMask=document.querySelector("#superMask");

//鼠标移入事件 中图随小图变换
ul.onmousemove=e=>{
    if(e.target.nodeName=="IMG"){
        mImg.src= e.target.dataset.md;
        largeDiv.style.backgroundImage=`url(${e.target.dataset.lg})`;
    }
}
var max=175
superMask.onmousemove=e=>{
    var  offsetX= e.offsetX,offsetY= e.offsetY;
    var  left=offsetX-175/2,top=offsetY-175/2;
    left=left<0?0:left>max?max:left;
    top=top<0?0:top>max?max:top;
    mask.style.left=left+"px";
    mask.style.top=top+"px";
    largeDiv.style.backgroundPosition=(-left*(800/350))+"px "+ (-top*(800/350))+"px";
}

var LIWIDTH=62,moved=0;
aForward.onclick=(e)=>{
    //moved++;
    //var left= LIWIDTH*moved +20;
    //ul.style.left=left+"px";
    if(e.target.className.indexOf("disabled")==-1)
        move(1);
}
aBackward.onclick=(e)=>{
    //moved--;
    //var left= LIWIDTH*moved +20;
    //ul.style.left=left+"px";
    if(e.target.className.indexOf("disabled")==-1)
        move(-1);
}
function move(dir){
    moved+=dir;
    var left= -LIWIDTH*moved +20;
    ul.style.left=left+"px";
    checkAll()
}
function checkAll(){
    if(moved==0){
        aBackward.className="backward disabled";
    }else if(ul.children.length-moved==5){
        aForward.className="forward disabled";
    }else{
        aBackward.className="backward";
        aForward.className="forward";
    }
}
superMask.onmouseover=()=>{
    mask.style.display=largeDiv.style.display="block";

}
superMask.onmouseout=()=>{
    mask.style.display=largeDiv.style.display="none";
}
})();
(()=>{
    var lid= location.search.split("=")[1];
    ajax({
        type:"get",
        url:"data/products/getProductByLid.php",
        data:"lid="+lid,
        dataType:"json"
    }).then(output=>{
           console.log(output);
           var {product,spec,imgs}=output;
          document.querySelector("#show-details>h1").innerHTML=product.title;
          document.querySelector("#show-details>h3>a").innerHTML=product.subtitle;
          document.querySelector("#show-details>.price>.stu-price>span").innerHTML=product.price;
          document.querySelector("#show-details>.price>.promise>span").innerHTML=product.promise;
         var html="";
         for(p of spec){
         html+=`<a href="product_details.html?lid=${p.lid}" class=${
              spec.lid===product.lid?"active":""
            }>${p.spec}</a>`;
          }
           document.querySelector("#show-details>.spec>div").innerHTML=html;
        var{title,os,memory,resolution,video_card,cpu,video_memory,category,disk,details}=product;
         document.querySelector("#param>ul").innerHTML=`<li>
                <a href="javascript:;">商品名称：${title}</a>
                </li>
                <li>
                <a href="javascript:;">系统：${os}</a>
                </li>
                <li>
                <a href="javascript:;">内存容量：${memory}</a>
                </li>
                <li>
                <a href="javascript:;">分辨率：${resolution}</a>
                </li>
                <li>
                <a href="javascript:;">显卡型号：${video_card}</a>
                </li>
                <li>
                <a href="javascript:;">处理器：${cpu}</a>
                </li>
                <li>
                <a href="javascript:;">显存容量：${video_memory}</a>
                </li>
                <li>
                <a href="javascript:;">分类：${category}</a>
                </li>
                <li>
                <a href="javascript:;">硬盘容量：${disk}</a>
                </li>`;
                    document.querySelector("#product-intro").innerHTML=details;
                  var html="";
                    for(pic of imgs){
                     html+=
                    `<li class="i1"><img src="${pic.sm}" data-md="${pic.md}" data-lg="${pic.lg}"></li>`;
                    }
                   document.querySelector("#icon_list").style.width=
                   62*imgs.length+"px";
                    if(imgs.length<=5)
                    document.querySelector("#preview>h1>a.forward")
                        .className="forward disabled";
                    document.querySelector("#icon_list").innerHTML=html;
                    document.querySelector("#mImg")
                        .src=imgs[0].md;
                    document.querySelector("#largeDiv").style.backgroundImage=
                        `url(${imgs[0].lg})`;

})
})();
